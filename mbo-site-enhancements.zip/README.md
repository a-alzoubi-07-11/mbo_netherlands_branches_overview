# MBO Netherlands Guide — generated enhancements

## Files
- `site-enhancements.js` — Apple-style tools, dark/light mode, saved pages, share, print, install hint, visitor badge.
- `manifest.webmanifest` — PWA metadata.
- `sw.js` — offline/service-worker cache.
- `INSTALL.txt` — exact integration steps.

## Important
The current GitHub integration can read the repository but cannot write to it (GitHub API returned HTTP 403). These files are therefore generated locally and are ready to add to the repository.
