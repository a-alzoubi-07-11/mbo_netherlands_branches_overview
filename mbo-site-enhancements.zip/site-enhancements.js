/* MBO Netherlands Guide — Apple-style enhancements
 * Add before </body>:
 * <script src="./site-enhancements.js" defer></script>
 */
(() => {
  "use strict";

  const STORE = {
    theme: "mbo_theme",
    saved: "mbo_saved_pages",
    lang: "lang"
  };

  const $ = (s, root = document) => root.querySelector(s);
  const safeGet = (k, fallback) => {
    try { const v = localStorage.getItem(k); return v ?? fallback; } catch (_) { return fallback; }
  };
  const safeSet = (k, v) => { try { localStorage.setItem(k, v); } catch (_) {} };

  const lang = () => document.documentElement.lang === "nl" ? "nl" : "ar";
  const rtl = () => document.documentElement.dir === "rtl";

  const i18n = {
    ar: {
      tools: "أدوات الموقع", theme: "الوضع الداكن", light: "الوضع الفاتح",
      save: "حفظ الصفحة", saved: "محفوظة", share: "مشاركة", print: "طباعة",
      install: "تثبيت الموقع", savedTitle: "صفحاتي المحفوظة",
      emptySaved: "لا توجد صفحات محفوظة بعد.", remove: "حذف",
      copied: "تم نسخ رابط الصفحة", savedMsg: "تم حفظ الصفحة", removedMsg: "تم حذف الصفحة",
      darkMsg: "تم تفعيل الوضع الداكن", lightMsg: "تم تفعيل الوضع الفاتح",
      installMsg: "يمكنك تثبيت الموقع من قائمة المتصفح.", shareMsg: "تمت المشاركة",
      visitor: "زائر الموقع"
    },
    nl: {
      tools: "Website-tools", theme: "Donkere modus", light: "Lichte modus",
      save: "Pagina opslaan", saved: "Opgeslagen", share: "Delen", print: "Afdrukken",
      install: "Website installeren", savedTitle: "Mijn opgeslagen pagina's",
      emptySaved: "Nog geen opgeslagen pagina's.", remove: "Verwijderen",
      copied: "Paginakoppeling gekopieerd", savedMsg: "Pagina opgeslagen", removedMsg: "Pagina verwijderd",
      darkMsg: "Donkere modus ingeschakeld", lightMsg: "Lichte modus ingeschakeld",
      installMsg: "Je kunt de website via het browsermenu installeren.", shareMsg: "Gedeeld",
      visitor: "Websitebezoeker"
    }
  };

  const t = k => (i18n[lang()][k] || i18n.ar[k] || k);

  function toast(message) {
    let el = $("#mboToast");
    if (!el) {
      el = document.createElement("div");
      el.id = "mboToast";
      document.body.appendChild(el);
    }
    el.textContent = message;
    el.classList.add("show");
    clearTimeout(el._timer);
    el._timer = setTimeout(() => el.classList.remove("show"), 2200);
  }

  function injectCSS() {
    if ($("#mboEnhanceCSS")) return;
    const style = document.createElement("style");
    style.id = "mboEnhanceCSS";
    style.textContent = `
      :root{
        --mbo-accent:#F97316;--mbo-panel:rgba(255,255,255,.88);
        --mbo-text:#0F172A;--mbo-border:rgba(15,23,42,.10);
      }
      html[data-theme="dark"]{
        color-scheme:dark;
        --bg:#0b1020!important;--bg2:#111827!important;--bg3:#182235!important;
        --slate-900:#F8FAFC!important;--slate-700:#CBD5E1!important;--slate-500:#94A3B8!important;
        --slate-400:#94A3B8!important;--slate-300:#475569!important;--slate-200:#334155!important;
        --slate-100:#1E293B!important;--brd:rgba(255,255,255,.10)!important;
        --brd2:rgba(255,255,255,.18)!important;--orange-l:rgba(249,115,22,.12)!important;
        --blue-bg:rgba(37,99,235,.14)!important;--green-bg:rgba(34,197,94,.12)!important;
        --amber-bg:rgba(217,119,6,.12)!important;--red-bg:rgba(220,38,38,.12)!important;
        --purple-bg:rgba(124,58,237,.13)!important;
      }
      html[data-theme="dark"] body{background:var(--bg);color:var(--slate-900)}
      html[data-theme="dark"] .navbar{background:rgba(11,16,32,.88)!important}
      html[data-theme="dark"] .card,html[data-theme="dark"] .panel,
      html[data-theme="dark"] .compare-card,html[data-theme="dark"] .salary-card{
        background:var(--bg2)!important;color:var(--slate-900)!important;
        border-color:var(--brd)!important;
      }
      html[data-theme="dark"] input,html[data-theme="dark"] select,
      html[data-theme="dark"] textarea{background:var(--bg2)!important;color:var(--slate-900)!important}
      .mbo-tools{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
      .mbo-tool-btn{
        width:38px;height:38px;border-radius:12px;display:inline-flex;align-items:center;
        justify-content:center;background:rgba(255,255,255,.08);
        border:1px solid rgba(255,255,255,.13);color:#fff;transition:.2s;
        font-size:16px;cursor:pointer;position:relative;
      }
      .mbo-tool-btn:hover{transform:translateY(-1px);background:rgba(255,255,255,.16)}
      .mbo-tool-btn[aria-pressed="true"]{background:rgba(249,115,22,.20);border-color:rgba(249,115,22,.5)}
      .mbo-save-count{
        position:absolute;top:-5px;right:-5px;min-width:17px;height:17px;padding:0 4px;
        border-radius:99px;background:#F97316;color:#fff;font-size:9px;font-weight:800;
        display:flex;align-items:center;justify-content:center;
      }
      .mbo-drawer-backdrop{position:fixed;inset:0;background:rgba(0,0,0,.42);z-index:950;opacity:0;visibility:hidden;transition:.25s}
      .mbo-drawer-backdrop.open{opacity:1;visibility:visible}
      .mbo-drawer{
        position:fixed;top:0;bottom:0;inset-inline-end:0;width:min(390px,92vw);z-index:960;
        background:var(--bg2,#fff);color:var(--slate-900,#0f172a);
        box-shadow:0 20px 60px rgba(0,0,0,.28);transform:translateX(105%);transition:.28s;
        padding:22px;overflow:auto;
      }
      html[dir="rtl"] .mbo-drawer{transform:translateX(-105%)}
      .mbo-drawer.open{transform:translateX(0)}
      .mbo-drawer-head{display:flex;align-items:center;justify-content:space-between;gap:12px;margin-bottom:18px}
      .mbo-drawer-head h2{font-size:20px;font-weight:900}
      .mbo-close{width:34px;height:34px;border-radius:10px;background:var(--bg3);border:1px solid var(--brd);cursor:pointer}
      .mbo-saved-item{
        display:flex;align-items:center;gap:10px;padding:12px;border:1px solid var(--brd);
        border-radius:14px;margin-bottom:8px;background:var(--bg2);cursor:pointer;
      }
      .mbo-saved-item:hover{border-color:rgba(249,115,22,.45);background:var(--orange-l)}
      .mbo-saved-main{flex:1;min-width:0}.mbo-saved-title{font-weight:800;font-size:13px}
      .mbo-saved-meta{font-size:11px;color:var(--slate-500);margin-top:2px}
      .mbo-remove{font-size:12px;color:#B91C1C;white-space:nowrap}
      .mbo-empty{text-align:center;color:var(--slate-500);padding:30px 12px}
      #mboToast{
        position:fixed;left:50%;bottom:24px;transform:translate(-50%,20px);
        background:#111827;color:#fff;padding:10px 16px;border-radius:999px;font-size:12px;
        font-weight:700;z-index:2000;opacity:0;pointer-events:none;transition:.25s;
        box-shadow:0 10px 30px rgba(0,0,0,.25)
      }
      #mboToast.show{opacity:1;transform:translate(-50%,0)}
      .mbo-visitor{
        display:inline-flex;align-items:center;gap:8px;margin:12px auto 0;padding:7px 13px;
        border-radius:999px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.13);
        color:rgba(255,255,255,.78);font-size:11px;font-weight:700
      }
      .mbo-visitor strong{color:#fff;font-variant-numeric:tabular-nums}
      @media(max-width:760px){
        .mbo-tools{width:100%;justify-content:flex-end}
        .mbo-tool-btn{width:36px;height:36px}
      }
      @media(prefers-reduced-motion:reduce){
        .mbo-tool-btn,.mbo-drawer,.mbo-drawer-backdrop,#mboToast{transition:none!important}
      }
      @media print{
        .mbo-tools,.mbo-drawer,.mbo-drawer-backdrop,#mboToast,.scroll-progress{display:none!important}
      }
    `;
    document.head.appendChild(style);
  }

  function currentPageId() {
    const active = $(".page.on");
    return active?.id || location.hash.replace("#","") || "overview";
  }

  function pageTitle() {
    const active = $(".page.on");
    const h = active?.querySelector("h1,h2,.sec-h");
    return (h?.textContent || document.title).trim();
  }

  function savedPages() {
    try { return JSON.parse(safeGet(STORE.saved, "[]")) || []; } catch (_) { return []; }
  }

  function writeSaved(items) { safeSet(STORE.saved, JSON.stringify(items)); }

  function isSaved() {
    return savedPages().some(x => x.id === currentPageId() && x.lang === lang());
  }

  function updateSaveButton() {
    const b = $("#mboSaveBtn");
    if (!b) return;
    const yes = isSaved();
    b.setAttribute("aria-pressed", yes ? "true" : "false");
    b.title = yes ? t("saved") : t("save");
    b.querySelector(".mbo-icon").textContent = yes ? "★" : "☆";
  }

  function updateSaveCount() {
    const badge = $("#mboSaveCount");
    if (!badge) return;
    const n = savedPages().length;
    badge.textContent = n;
    badge.hidden = n === 0;
  }

  function saveCurrent() {
    const id = currentPageId();
    const items = savedPages().filter(x => !(x.id === id && x.lang === lang()));
    if (isSaved()) {
      writeSaved(items);
      toast(t("removedMsg"));
    } else {
      items.unshift({id, lang:lang(), title:pageTitle(), url:location.href.split("#")[0] + "#" + id, ts:Date.now()});
      writeSaved(items.slice(0,50));
      toast(t("savedMsg"));
    }
    updateSaveButton(); updateSaveCount(); renderDrawer();
  }

  function openDrawer() {
    renderDrawer();
    $("#mboDrawerBackdrop")?.classList.add("open");
    $("#mboDrawer")?.classList.add("open");
  }

  function closeDrawer() {
    $("#mboDrawerBackdrop")?.classList.remove("open");
    $("#mboDrawer")?.classList.remove("open");
  }

  function renderDrawer() {
    const list = $("#mboSavedList");
    if (!list) return;
    const items = savedPages();
    list.innerHTML = "";
    if (!items.length) {
      list.innerHTML = `<div class="mbo-empty">${t("emptySaved")}</div>`;
      return;
    }
    for (const item of items) {
      const row = document.createElement("div");
      row.className = "mbo-saved-item";
      row.innerHTML = `<div class="mbo-saved-main"><div class="mbo-saved-title"></div><div class="mbo-saved-meta"></div></div><button class="mbo-remove" type="button">${t("remove")}</button>`;
      $(".mbo-saved-title", row).textContent = item.title || item.id;
      $(".mbo-saved-meta", row).textContent = `${item.lang.toUpperCase()} · ${new Date(item.ts).toLocaleDateString()}`;
      $(".mbo-saved-main", row).addEventListener("click", () => {
        closeDrawer();
        if (typeof window.setPage === "function") window.setPage(item.id);
        else location.hash = item.id;
      });
      $(".mbo-remove", row).addEventListener("click", e => {
        e.stopPropagation();
        writeSaved(savedPages().filter(x => !(x.id === item.id && x.lang === item.lang)));
        renderDrawer(); updateSaveButton(); updateSaveCount();
      });
      list.appendChild(row);
    }
  }

  function applyTheme(theme, announce=true) {
    const next = theme === "dark" ? "dark" : "light";
    document.documentElement.setAttribute("data-theme", next);
    safeSet(STORE.theme, next);
    const btn = $("#mboThemeBtn");
    if (btn) {
      btn.setAttribute("aria-pressed", next === "dark" ? "true" : "false");
      btn.title = next === "dark" ? t("light") : t("theme");
      btn.querySelector(".mbo-icon").textContent = next === "dark" ? "☀︎" : "☾";
    }
    if (announce) toast(next === "dark" ? t("darkMsg") : t("lightMsg"));
  }

  async function sharePage() {
    const data = {title:pageTitle(), text:pageTitle(), url:location.href};
    try {
      if (navigator.share) {
        await navigator.share(data);
        toast(t("shareMsg"));
        return;
      }
      await navigator.clipboard.writeText(location.href);
      toast(t("copied"));
    } catch (_) {}
  }

  function installPWA() {
    if (window.__mboDeferredInstall) {
      window.__mboDeferredInstall.prompt();
      window.__mboDeferredInstall.userChoice.finally(() => window.__mboDeferredInstall = null);
    } else {
      toast(t("installMsg"));
    }
  }

  function injectManifest() {
    if ($('link[rel="manifest"]')) return;
    const manifest = {
      name: "دليل النظام التعليمي الهولندي الشامل",
      short_name: "دليل هولندا",
      start_url: "./",
      display: "standalone",
      background_color: "#F8FAFC",
      theme_color: "#F5F5F7",
      lang: lang(),
      dir: rtl() ? "rtl" : "ltr",
      icons: []
    };
    const blob = new Blob([JSON.stringify(manifest)], {type:"application/manifest+json"});
    const url = URL.createObjectURL(blob);
    const link = document.createElement("link");
    link.rel = "manifest"; link.href = url;
    document.head.appendChild(link);
  }

  function buildTools() {
    const top = $(".tl-right") || $(".topbar");
    if (!top || $("#mboTools")) return;
    const tools = document.createElement("div");
    tools.id = "mboTools";
    tools.className = "mbo-tools";
    tools.innerHTML = `
      <button class="mbo-tool-btn" id="mboThemeBtn" type="button" aria-pressed="false" title="${t("theme")}"><span class="mbo-icon">☾</span></button>
      <button class="mbo-tool-btn" id="mboSaveBtn" type="button" aria-pressed="false" title="${t("save")}"><span class="mbo-icon">☆</span><span class="mbo-save-count" id="mboSaveCount" hidden>0</span></button>
      <button class="mbo-tool-btn" id="mboShareBtn" type="button" title="${t("share")}"><span class="mbo-icon">↗</span></button>
      <button class="mbo-tool-btn" id="mboPrintBtn" type="button" title="${t("print")}"><span class="mbo-icon">⎙</span></button>
      <button class="mbo-tool-btn" id="mboSavedBtn" type="button" title="${t("saved")}"><span class="mbo-icon">▤</span></button>
      <button class="mbo-tool-btn" id="mboInstallBtn" type="button" title="${t("install")}"><span class="mbo-icon">⌄</span></button>
    `;
    top.appendChild(tools);

    $("#mboThemeBtn").onclick = () => applyTheme(document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark");
    $("#mboSaveBtn").onclick = saveCurrent;
    $("#mboShareBtn").onclick = sharePage;
    $("#mboPrintBtn").onclick = () => window.print();
    $("#mboSavedBtn").onclick = openDrawer;
    $("#mboInstallBtn").onclick = installPWA;
  }

  function buildDrawer() {
    if ($("#mboDrawer")) return;
    const backdrop = document.createElement("div");
    backdrop.id = "mboDrawerBackdrop";
    backdrop.className = "mbo-drawer-backdrop";
    const drawer = document.createElement("aside");
    drawer.id = "mboDrawer";
    drawer.className = "mbo-drawer";
    drawer.setAttribute("aria-label", t("savedTitle"));
    drawer.innerHTML = `
      <div class="mbo-drawer-head"><h2>${t("savedTitle")}</h2><button class="mbo-close" type="button" aria-label="Close">×</button></div>
      <div id="mboSavedList"></div>
    `;
    document.body.append(backdrop, drawer);
    backdrop.onclick = closeDrawer;
    $(".mbo-close", drawer).onclick = closeDrawer;
  }

  function addVisitorBadge() {
    if ($(".mbo-visitor")) return;
    const hero = $(".hero-inner") || $(".hero");
    if (!hero) return;
    const node = document.createElement("div");
    node.className = "mbo-visitor";
    node.innerHTML = `◉ <span>${t("visitor")}</span> <strong id="mboVisitorNumber">—</strong>`;
    hero.appendChild(node);

    // Uses the same public counter API already used by the site when available.
    const SITE = "a-alzoubi-07-11.github.io";
    const PATH = "/mbo_netherlands_branches_overview/";
    const API = "https://page-views-api.ratneshc.com/api/v1";
    const key = "mbo_visitor_fallback";
    let local = Number(safeGet(key, "0")) || 0;
    local += 1;
    safeSet(key, String(local));
    $("#mboVisitorNumber").textContent = local.toLocaleString();

    fetch(`${API}/track?site=${encodeURIComponent(SITE)}&path=${encodeURIComponent(PATH)}`, {method:"POST", mode:"cors"})
      .then(() => fetch(`${API}/views?site=${encodeURIComponent(SITE)}&path=${encodeURIComponent(PATH)}`))
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        const n = data?.views ?? data?.count ?? data?.total;
        if (Number.isFinite(Number(n))) $("#mboVisitorNumber").textContent = Number(n).toLocaleString();
      }).catch(() => {});
  }

  function setupInstallCapture() {
    window.addEventListener("beforeinstallprompt", e => {
      e.preventDefault();
      window.__mboDeferredInstall = e;
      const b = $("#mboInstallBtn");
      if (b) b.hidden = false;
    });
  }

  function syncAfterNavigation() {
    updateSaveButton();
    updateSaveCount();
    renderDrawer();
  }

  function boot() {
    injectCSS();
    injectManifest();
    buildTools();
    buildDrawer();
    addVisitorBadge();
    setupInstallCapture();

    const savedTheme = safeGet(STORE.theme, "");
    const systemDark = window.matchMedia?.("(prefers-color-scheme: dark)").matches;
    applyTheme(savedTheme || (systemDark ? "dark" : "light"), false);
    syncAfterNavigation();

    // Observe hash changes and the existing setPage() navigation.
    window.addEventListener("hashchange", () => setTimeout(syncAfterNavigation, 80));

    if (typeof window.setPage === "function" && !window.setPage.__mboWrapped) {
      const original = window.setPage;
      const wrapped = function(...args) {
        const result = original.apply(this, args);
        setTimeout(syncAfterNavigation, 80);
        return result;
      };
      wrapped.__mboWrapped = true;
      window.setPage = wrapped;
    }

    // Re-apply translated labels when the existing site switches language.
    const observer = new MutationObserver(() => {
      if ($("#mboThemeBtn")) {
        const dark = document.documentElement.getAttribute("data-theme") === "dark";
        $("#mboThemeBtn").title = dark ? t("light") : t("theme");
        $("#mboSaveBtn").title = isSaved() ? t("saved") : t("save");
        $("#mboSavedBtn").title = t("saved");
        $("#mboInstallBtn").title = t("install");
      }
    });
    observer.observe(document.documentElement, {attributes:true, attributeFilter:["lang","dir"]});
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", boot);
  else boot();
})();
